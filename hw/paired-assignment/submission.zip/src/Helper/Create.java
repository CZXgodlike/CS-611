package Helper;

public interface Create {
    public <T> T create(String name);
}
