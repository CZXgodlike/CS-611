package Creatures;

import java.util.List;

/**
 * Class represents an exoskeleton
 */
public class Exoskeleton extends Monster{

    public Exoskeleton(){super();}

    public Exoskeleton(List<String> list){
        super(list);
    }
}
