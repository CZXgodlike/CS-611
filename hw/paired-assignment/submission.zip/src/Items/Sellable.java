package Items;

public interface Sellable {

    public boolean isBuyable(int balance, int level);
}
