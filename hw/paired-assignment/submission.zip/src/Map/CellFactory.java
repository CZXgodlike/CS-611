package Map;

public abstract class CellFactory {
	public abstract Cell createCell();
}
