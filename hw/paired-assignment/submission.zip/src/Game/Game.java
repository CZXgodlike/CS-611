package Game;

public abstract class Game {

    public Game(){}
    
    public abstract void start();
}
