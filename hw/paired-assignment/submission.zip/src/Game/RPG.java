package Game;

import UserInterface.TextMessageDecorator;

public abstract class RPG extends Game{

    private TextMessageDecorator tmd;

    public RPG(){}
}
