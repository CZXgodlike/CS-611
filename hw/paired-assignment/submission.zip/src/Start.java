import Game.LegendsOfValor;

public class Start {
    public static void main(String[] args) {
        LegendsOfValor legends = new LegendsOfValor();
        legends.start();
     }
}