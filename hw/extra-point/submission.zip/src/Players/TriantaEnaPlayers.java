package Players;

import java.util.List;

public class TriantaEnaPlayers extends Players <TriantaEnaPlayer>{

    protected List<TriantaEnaPlayer> players;

    public TriantaEnaPlayers(){
        super();
    }

    public TriantaEnaPlayers(List<TriantaEnaPlayer> players){
        super(players);
    }



}
