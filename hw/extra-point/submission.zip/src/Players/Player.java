package Players;

import Human.Human;

public abstract class Player extends Human {


    public Player(String name){
        super(name);
    }

    public Player(){}


}
