import Games.Game;
import Games.TriantaEna;

public class Start {

    public static void main(String[] args) {
        Game game = new TriantaEna();
        game.start();
    }
}
