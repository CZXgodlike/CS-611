package Games;

public abstract class Game {

    public Game(){}

    public abstract void start();
}
